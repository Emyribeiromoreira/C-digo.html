# Projeto Site Acessível - 3° Ano Ensino médio

# Sobre
Refatoração de um site implementando recursos de acessibilidade no html, css e JS.

## Recursos de acessibilidade
- atributos ARIA;
- alt;
- tab-index;
- menu acessibiliade:
-   Aumento de tamanho de fonte;
-   Diminuição de tamanho de fonte;
-   Alto Contraste;
-   Leitores de página web;

## Tecnologias utilizadas
- bootstrap;
- ScrollReveals;
- HTML;
- CSS;
- JS;
